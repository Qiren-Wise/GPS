#include <Adafruit_GFX.h>

// This font is based on Bodoni MT 24pt, slightly corrected in picture editor
extern const GFXfont TimeFont;