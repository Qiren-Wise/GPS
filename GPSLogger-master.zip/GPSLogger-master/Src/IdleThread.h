#ifndef IDLETHREAD_H_
#define IDLETHREAD_H_

float getCPULoad();
float getMaxCPULoad();

#endif //IDLETHREAD_H_
