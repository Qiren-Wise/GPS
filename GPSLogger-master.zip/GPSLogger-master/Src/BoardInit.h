#ifndef BOARDINIT_H
#define BOARDINIT_H

void InitBoard();

#endif // BOARDINIT_H
