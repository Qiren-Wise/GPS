#ifndef GPSDATA_H_
#define GPSDATA_H_

#include "GPSSatellitesData.h"
#include "Arduino_FreeRTOS.h"

// Forward declarations
class gps_fix;
class GPSSatellitesData;
class NMEAGPS;
class GPSOdometer;
class GPSOdometerData;

const uint8_t ODOMERTERS_COUNT = 3;

/**
 * GPS data model. Encapsulates all the knowledge about various GPS related data in the device
 */
class GPSDataModel
{
public:
	/// A single instance of the model
	static GPSDataModel & instance();

	void processNewGPSFix(const gps_fix & fix);
	void processNewSatellitesData(NMEAGPS::satellite_view_t * sattelites, uint8_t count);
	gps_fix getGPSFix() const;
	GPSSatellitesData getSattelitesData() const;
	
	float getVerticalSpeed() const;
	int timeDifference() const;
	
	// Odometers
	GPSOdometerData getOdometerData(uint8_t idx) const;
	void resumeOdometer(uint8_t idx);
	void pauseOdometer(uint8_t idx);
	void resetOdometer(uint8_t idx);
	void resumeAllOdometers();
	void pauseAllOdometers();
	void resetAllOdometers();
	
private:
	gps_fix cur_fix; /// most recent fix data
	gps_fix prev_fix; /// previously set fix data
	GPSSatellitesData sattelitesData; // Sattelites count and signal power
	GPSOdometer * odometers[ODOMERTERS_COUNT];
	bool odometerWasActive[ODOMERTERS_COUNT];
	
	SemaphoreHandle_t xGPSDataMutex;
	StaticSemaphore_t xGPSDataMutexBuffer;
	
	GPSDataModel();
	GPSDataModel( const GPSDataModel &c );
	GPSDataModel& operator=( const GPSDataModel &c );	
}; //GPSDataModel

#endif //GPSDATA_H_
