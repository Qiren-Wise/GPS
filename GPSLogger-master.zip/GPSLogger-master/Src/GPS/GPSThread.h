#ifndef GPSTHREAD_H_
#define GPSTHREAD_H_

void initGPS();
void vGPSTask(void *pvParameters);

#endif //GPSTHREAD_H_
