/*
 * FontTest.h
 *
 * Created: 28.01.2017 22:37:32
 *  Author: GrafAlex
 */ 


#ifndef FONTTEST_H_
#define FONTTEST_H_

void RunFontTest();
void SwitchToNextFont();

#endif /* FONTTEST_H_ */