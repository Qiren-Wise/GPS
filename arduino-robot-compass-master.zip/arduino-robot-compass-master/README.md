# arduino-robot-compass [![Build Status](https://travis-ci.org/openhardwarerobots/arduino-robot-compass.svg)](https://travis-ci.org/openhardwarerobots/arduino-robot-compass)

Code for basic use of a digital compass for a mobile robot
