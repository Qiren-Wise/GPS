#include "Adafruit_Sensor.h"
#include <avr/pgmspace.h>

void Adafruit_Sensor::constructor() {
}
