arduino-airquality - Dust Sensor
==================

In the Dust Sensor Module, we are building a standalone Dust Sensor using the Arduino Fio.

For a detailled documentation including a parts list, check out the following blog post
http://arduinodev.woofex.net/2012/12/01/standalone-sharp-dust-sensor/

# Assembly

![Dust_SensorArduino](https://raw.github.com/Trefex/arduino-airquality/master/Module_Dust-Sensor/assembly/Arduino_Fio_Sketch_Fritzing_schem_small.jpg)


