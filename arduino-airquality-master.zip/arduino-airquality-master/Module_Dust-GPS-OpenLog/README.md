arduino-airquality - Combine Dust Sensor - GPS - OpenLog
==================

In this project, we are building a combination module of the Sharp Dust Sensor, the Adafruit Ultimate GPS Breakout v3 and the OpenLog using the Arduino Fio.

For a detailled documentation including a parts list, check out the following blog post
http://arduinodev.woofex.net/2012/12/16/sharp-dust-sensor-with-adafruit-gps-v3

# Assembly



