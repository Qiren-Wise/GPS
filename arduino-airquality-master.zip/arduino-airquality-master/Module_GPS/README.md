arduino-airquality - GPS
==================

In the GPS Module, we are building a standalone GPS device using the Arduino Fio.
This will be used as a module in the AirQuality project.

Stay tuned for updates.