# Contributing

Please see our [Contributing Guide](https://github.com/bolderflight/contributing) for tips on how to effectively make contributions to our project.
