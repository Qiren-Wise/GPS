# QMC5883
QMC5883 compass module for Arduino

For modified module QMC5883 instead of HMC5883.

Call calculate() function before using any other function.

Retrieve individual x, y, z readings with getX(), getY(), and getZ(), or 

directly use getHeading('z') or getHeadingDegree('z') for getting the 

heading angle with 'z' axis pointing upward. Use a single lower-case letter 

to indicate the axis.
  
  


Author: Michael Huang

Version: V1.2 - 20170612
