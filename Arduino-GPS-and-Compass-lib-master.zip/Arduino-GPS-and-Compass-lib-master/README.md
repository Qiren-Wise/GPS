Arduino-GPS-and-Compass-lib
===========================

An Arduino library for reading position and heading information from GPS and Compass. Developed and Tested primarily with Locosys LS20126 GPS+Compass module
