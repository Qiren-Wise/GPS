ARMA 3 Compass Arduino Code

This is part of my ARMA 3 desktop compass project. This is the code running on the Arduino Board.

You need the Arduino IDE to build and upload this code to your board.
https://www.arduino.cc/en/main/software